package com.cofe.solution.ui.device.config.intelligentvigilance.alert.view;


import java.util.List;

import com.lib.sdk.bean.smartanalyze.Points;

/**
 * Created by zhangyongyong on 2017-05-09-12:57.
 */

public interface AlertSetPreViewInterface {
	List<Points> getConvertPoint(int width, int height);
}
