package com.cofe.solution.ui.device.add.list.listener;

/**
 * @author hws
 * @class
 * @time 2020/10/27 15:09
 */
public interface ChannelListContract {
    interface IChannelListView {

    }

    interface IChannelListPresenter {
    }
}
