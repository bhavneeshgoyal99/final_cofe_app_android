package com.cofe.solution.ui.device.setting;

public interface IConfigBase {
	String getSendMsg();
	boolean onParse(String json);
}
