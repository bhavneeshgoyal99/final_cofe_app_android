package com.cofe.solution.ui.device.config.simpleconfig.presenter;

import com.manager.base.BaseManager;
import com.xm.activity.base.XMBasePresenter;

public class ConfigNameSelPresenter extends XMBasePresenter {
    @Override
    protected BaseManager getManager() {
        return null;
    }
}
