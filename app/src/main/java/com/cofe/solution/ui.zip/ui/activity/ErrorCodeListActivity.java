package com.cofe.solution.ui.activity;

import android.os.Bundle;

import com.xm.activity.base.XMBaseActivity;
import com.xm.activity.base.XMBasePresenter;

import com.cofe.solution.base.DemoBaseActivity;

/**
 * @author hws
 * @class
 * @time 2020/10/24 11:17
 */
public class ErrorCodeListActivity extends DemoBaseActivity {

    @Override
    public XMBasePresenter getPresenter() {
        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
